import hashlib
flag=0
while True:
		 print("This is Password Cracker Tool based on dictionary attack")
		 print('Press "1" to crack "md5" hash password :')
		 print('Press "2" to crack "sha1" hash password:') 
		 print('Press "3" to crack "sha224" hash password:')
		 print('Press "4" to crack "sha256" hash password :')
		 print('Press "6" to crack "sha512" hash password:') 
		 print('Press "7" to "Quit"')
		 choice = input("Enter Choice: 1 or 2 or 3 or 4 or 5 or 6 or 7: ")
		 print(choice)
		 if choice=="1":
			 hash_password =input("Enter ads hash: ") 
			 break
		 elif choice=="2":
			 hash_password = input("Enter shal hash: ")
			 break
		 elif choice=="3":
			 hash_password = input("Enter sha224 hash: ") 
			 break
		 elif choice=="4":
		     hash_password = input("Enter sha256 hash: ") 
		     break
		 elif choice=="5":
			 hash_password = input("Enter sha384 hash: ") 
			 break
		 elif choice=="6":
			 hash_password = input("Enter sha512 hash: ")
			 break 
		 elif choice=="7":
			 quit()
wordlist = input("File Name: ")
try : 
     pass_file = open(wordlist, "r")
except:
     print("No file found")
     quit()
for word in pass_file:
     enc_word = word.encode('utf-8') 
        if algorithm == "1":
			digest=hashlib.md5(enc_word.strip()).hexdigest()
		elif algorithm == "2":
			digest=hashlib.shal(enc_word.strip()).hexdigest()
		elif algorithm=="3": 
			digest=hashlib.sha224(enc_word.strip()).hexdigest() 
		elif algorithm =="4":
			digest=hashlib.sha256(enc_word.strip()).hexdigest() 
		elif algorithm="5":
			digest=hashlib.sha384(enc_word.strip()).hexdigest()
		elif algorithm == "6":
			digest=hashlib.sha512(enc_word.strip()).hexdigest()
     if digest == hash_password:
          print("password found")
          print("password is " + word)
          flag = 1
          break
if flag == 0: 
     print("password is not in the list")