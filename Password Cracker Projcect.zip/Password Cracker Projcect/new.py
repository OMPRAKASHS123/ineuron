x=6
y=8
c=x+y
print(c)