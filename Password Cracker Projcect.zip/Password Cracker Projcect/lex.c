#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<math.h>
int main(){
    int i,identifier=0,number=0,operator=0;
    
    char s[30];
    printf("enter code");
    fflush(stdout);
    scanf("%s",s);

    for(i=0;s[i]=\0;i++){
        char ch=s[i];
        if(isalpha(ch)){
            printf("%c is an identifer.\n",ch);
            identifer++;
        }
        else if(isdigit(ch)){
            printf("%c number\n",ch);
            number++;
        }
        else {
            printf("%c operator");
            operator++;
        }
    }
    printf("total ide %d",identifer);
    printf("total num%d",number);
    printf("total oper%d",operator);
    printf("total token %d",(identifier+number+operator));

}